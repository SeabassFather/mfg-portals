// =============================================================================
// SECURITY HUB MODULE
// =============================================================================
// 9 Security & Compliance Niner Miners
// 49ers Colors: Black #000000, Gold #B3995D, Red #AA0000
// Manages: Threats, Authentication, Encryption, Audits, Compliance
// =============================================================================

import React, { useState, useEffect } from 'react';

const SECURITY_MINERS = [
  { id: 'guard_ranger', name: 'Guard Ranger', status: 'ACTIVE', currentTask: 'Perimeter security monitoring', tasksCompleted: 2891 },
  { id: 'auth_marshal', name: 'Auth Marshal', status: 'ACTIVE', currentTask: 'Authentication verification', tasksCompleted: 4567 },
  { id: 'encrypt_sheriff', name: 'Encrypt Sheriff', status: 'ACTIVE', currentTask: 'Data encryption protocols', tasksCompleted: 1923 },
  { id: 'firewall_deputy', name: 'Firewall Deputy', status: 'ACTIVE', currentTask: 'Firewall rule management', tasksCompleted: 1456 },
  { id: 'audit_tracker', name: 'Audit Tracker', status: 'ACTIVE', currentTask: 'Security audit logging', tasksCompleted: 3782 },
  { id: 'compliance_scout', name: 'Compliance Scout', status: 'ACTIVE', currentTask: 'Compliance monitoring', tasksCompleted: 987 },
  { id: 'threat_hunter', name: 'Threat Hunter', status: 'ACTIVE', currentTask: 'Threat detection analysis', tasksCompleted: 2134 },
  { id: 'vulnerability_wrangler', name: 'Vulnerability Wrangler', status: 'ACTIVE', currentTask: 'Vulnerability scanning', tasksCompleted: 1678 },
  { id: 'policy_enforcer', name: 'Policy Enforcer', status: 'ACTIVE', currentTask: 'Security policy enforcement', tasksCompleted: 2345 }
];

export default function SecurityHub() {
  const [miners, setMiners] = useState(SECURITY_MINERS);
  const [metrics, setMetrics] = useState({
    threatsBlocked: Math.floor(Math.random() * 50) + 10,
    authAttempts: Math.floor(Math.random() * 1000) + 500,
    complianceScore: Math.floor(Math.random() * 3) + 97,
    activeAlerts: Math.floor(Math.random() * 5) + 1
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics({
        threatsBlocked: Math.floor(Math.random() * 50) + 10,
        authAttempts: Math.floor(Math.random() * 1000) + 500,
        complianceScore: Math.floor(Math.random() * 3) + 97,
        activeAlerts: Math.floor(Math.random() * 5) + 1
      });
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, rgba(0,0,0,0.98) 0%, rgba(26,26,26,0.95) 100%)',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* BACKGROUND PATTERN */}
      <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, opacity: 0.03 }}>
        <defs>
          <pattern id="security-grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(170,0,0,0.05)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#security-grid)" />
      </svg>

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* HEADER */}
        <div style={{
          background: '#000000',
          border: '3px solid #AA0000',
          borderTop: '6px solid #AA0000',
          borderRadius: 0,
          padding: '24px',
          marginBottom: '24px'
        }}>
          <h1 style={{ color: '#AA0000', fontSize: '32px', fontWeight: '700', margin: '0 0 8px 0', letterSpacing: '2px' }}>
            SECURITY & COMPLIANCE HUB
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>
            9 Security & Compliance Niner Miners • 24/7 Threat Monitoring
          </p>
        </div>

        {/* METRICS ROW */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
          <div style={{
            background: '#000000',
            border: '2px solid #AA0000',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              THREATS BLOCKED (24H)
            </div>
            <div style={{ color: '#AA0000', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.threatsBlocked}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              AUTH ATTEMPTS
            </div>
            <div style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.authAttempts}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #22c55e',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              COMPLIANCE SCORE
            </div>
            <div style={{ color: '#22c55e', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.complianceScore}%
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #AA0000',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              ACTIVE ALERTS
            </div>
            <div style={{ color: '#AA0000', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.activeAlerts}
            </div>
          </div>
        </div>

        {/* MAIN GRID */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* NINER MINERS PANEL */}
          <div style={{
            background: '#000000',
            border: '3px solid #AA0000',
            borderRadius: 0,
            padding: '24px'
          }}>
            <h2 style={{ color: '#AA0000', fontSize: '20px', fontWeight: '700', marginBottom: '20px', letterSpacing: '1px' }}>
              SECURITY NINER MINERS
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {miners.map(miner => (
                <div
                  key={miner.id}
                  style={{
                    background: '#000000',
                    border: '2px solid #AA0000',
                    borderRadius: 0,
                    padding: '16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '4px' }}>
                      <div style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: miner.status === 'ACTIVE' ? '#22c55e' : '#AA0000'
                      }} />
                      <span style={{ color: '#AA0000', fontSize: '14px', fontWeight: '700' }}>
                        {miner.name}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '11px', marginLeft: '20px' }}>
                      {miner.currentTask}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', fontFamily: 'monospace' }}>
                      {miner.tasksCompleted.toLocaleString()}
                    </div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>TASKS</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ACTIVITY PANEL */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* SECURITY EVENTS */}
            <div style={{
              background: '#000000',
              border: '3px solid #AA0000',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#AA0000', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                RECENT SECURITY EVENTS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[
                  { type: 'Failed Login Attempt', severity: 'MEDIUM', time: '1m ago', details: 'IP: 192.168.1.47' },
                  { type: 'Suspicious API Call', severity: 'HIGH', time: '3m ago', details: 'Endpoint: /admin/users' },
                  { type: 'DDoS Attempt Blocked', severity: 'CRITICAL', time: '7m ago', details: '1,247 requests/sec' },
                  { type: 'Password Change', severity: 'LOW', time: '12m ago', details: 'User: admin@auditdna.com' },
                  { type: 'Firewall Rule Violation', severity: 'MEDIUM', time: '18m ago', details: 'Port 8080 blocked' }
                ].map((event, i) => (
                  <div key={i} style={{
                    background: '#000000',
                    border: `1px solid ${event.severity === 'CRITICAL' ? '#AA0000' : event.severity === 'HIGH' ? '#f97316' : event.severity === 'MEDIUM' ? '#B3995D' : '#22c55e'}`,
                    borderRadius: 0,
                    padding: '12px'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ color: '#AA0000', fontSize: '12px', fontWeight: '600' }}>{event.type}</span>
                      <span style={{
                        color: event.severity === 'CRITICAL' ? '#AA0000' : event.severity === 'HIGH' ? '#f97316' : event.severity === 'MEDIUM' ? '#B3995D' : '#22c55e',
                        fontSize: '10px',
                        fontWeight: '700'
                      }}>
                        {event.severity}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '2px' }}>{event.details}</div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>{event.time}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* COMPLIANCE STATUS */}
            <div style={{
              background: '#000000',
              border: '3px solid #B3995D',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                COMPLIANCE STATUS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>SOC 2 Compliance</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700' }}>
                      100%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '100%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>GDPR Compliance</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700' }}>
                      98%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '98%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>HIPAA Compliance</span>
                    <span style={{ color: '#B3995D', fontSize: '14px', fontWeight: '700' }}>
                      95%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #AA0000 100%)',
                      height: '100%',
                      width: '95%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
