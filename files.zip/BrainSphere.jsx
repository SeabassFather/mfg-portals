// =============================================================================
// THE SPHERE - BRAIN VISUALIZATION
// =============================================================================
// 3D visualization of all 81 Niner Miners inside THE BRAIN
// Real-time activity, task assignments, and workflow monitoring
// 49ers Colors: Black, Gold (#B3995D), Red (#AA0000)
// =============================================================================

import React, { useState, useEffect } from 'react';

// 81 NINER MINERS - Complete roster with positions in sphere
const ALL_MINERS = [
  // TEAM 1: DATA INTELLIGENCE (Green cluster)
  { id: 'data_harvester', name: 'Data Harvester', team: 'Data Intelligence', color: '#22c55e', x: -200, y: -100, z: 0 },
  { id: 'pattern_scout', name: 'Pattern Scout', team: 'Data Intelligence', color: '#22c55e', x: -180, y: -80, z: 20 },
  { id: 'insight_tracker', name: 'Insight Tracker', team: 'Data Intelligence', color: '#22c55e', x: -160, y: -90, z: -20 },
  { id: 'trend_ranger', name: 'Trend Ranger', team: 'Data Intelligence', color: '#22c55e', x: -190, y: -70, z: 10 },
  { id: 'metric_wrangler', name: 'Metric Wrangler', team: 'Data Intelligence', color: '#22c55e', x: -170, y: -110, z: 15 },
  { id: 'analytics_sheriff', name: 'Analytics Sheriff', team: 'Data Intelligence', color: '#22c55e', x: -185, y: -95, z: -15 },
  { id: 'query_outlaw', name: 'Query Outlaw', team: 'Data Intelligence', color: '#22c55e', x: -195, y: -85, z: 5 },
  { id: 'database_marshal', name: 'Database Marshal', team: 'Data Intelligence', color: '#22c55e', x: -175, y: -105, z: 25 },
  { id: 'cache_gunslinger', name: 'Cache Gunslinger', team: 'Data Intelligence', color: '#22c55e', x: -165, y: -75, z: -10 },

  // TEAM 2: WORKFLOW AUTOMATION (Gold cluster)
  { id: 'process_pioneer', name: 'Process Pioneer', team: 'Workflow Automation', color: '#B3995D', x: 200, y: -100, z: 0 },
  { id: 'task_buckaroo', name: 'Task Buckaroo', team: 'Workflow Automation', color: '#B3995D', x: 180, y: -80, z: 20 },
  { id: 'automation_ace', name: 'Automation Ace', team: 'Workflow Automation', color: '#B3995D', x: 160, y: -90, z: -20 },
  { id: 'workflow_deputy', name: 'Workflow Deputy', team: 'Workflow Automation', color: '#B3995D', x: 190, y: -70, z: 10 },
  { id: 'schedule_rider', name: 'Schedule Rider', team: 'Workflow Automation', color: '#B3995D', x: 170, y: -110, z: 15 },
  { id: 'trigger_trailblazer', name: 'Trigger Trailblazer', team: 'Workflow Automation', color: '#B3995D', x: 185, y: -95, z: -15 },
  { id: 'event_wrangler', name: 'Event Wrangler', team: 'Workflow Automation', color: '#B3995D', x: 195, y: -85, z: 5 },
  { id: 'pipeline_rustler', name: 'Pipeline Rustler', team: 'Workflow Automation', color: '#B3995D', x: 175, y: -105, z: 25 },
  { id: 'orchestrator_outlaw', name: 'Orchestrator Outlaw', team: 'Workflow Automation', color: '#B3995D', x: 165, y: -75, z: -10 },

  // TEAM 3: SECURITY & COMPLIANCE (Red cluster)
  { id: 'guard_ranger', name: 'Guard Ranger', team: 'Security & Compliance', color: '#AA0000', x: 0, y: 200, z: 0 },
  { id: 'auth_marshal', name: 'Auth Marshal', team: 'Security & Compliance', color: '#AA0000', x: 20, y: 180, z: 20 },
  { id: 'encrypt_sheriff', name: 'Encrypt Sheriff', team: 'Security & Compliance', color: '#AA0000', x: -20, y: 190, z: -20 },
  { id: 'firewall_deputy', name: 'Firewall Deputy', team: 'Security & Compliance', color: '#AA0000', x: 10, y: 170, z: 10 },
  { id: 'audit_tracker', name: 'Audit Tracker', team: 'Security & Compliance', color: '#AA0000', x: 15, y: 195, z: 15 },
  { id: 'compliance_scout', name: 'Compliance Scout', team: 'Security & Compliance', color: '#AA0000', x: -15, y: 185, z: -15 },
  { id: 'threat_hunter', name: 'Threat Hunter', team: 'Security & Compliance', color: '#AA0000', x: 5, y: 175, z: 5 },
  { id: 'vulnerability_wrangler', name: 'Vulnerability Wrangler', team: 'Security & Compliance', color: '#AA0000', x: 25, y: 205, z: 25 },
  { id: 'policy_enforcer', name: 'Policy Enforcer', team: 'Security & Compliance', color: '#AA0000', x: -10, y: 165, z: -10 },

  // TEAM 4: INTEGRATION & API (Orange/Gold cluster)
  { id: 'api_pathfinder', name: 'API Pathfinder', team: 'Integration & API', color: '#B3995D', x: 0, y: -200, z: 0 },
  { id: 'endpoint_explorer', name: 'Endpoint Explorer', team: 'Integration & API', color: '#B3995D', x: 20, y: -180, z: 20 },
  { id: 'webhook_wanderer', name: 'Webhook Wanderer', team: 'Integration & API', color: '#B3995D', x: -20, y: -190, z: -20 },
  { id: 'rest_rustler', name: 'REST Rustler', team: 'Integration & API', color: '#B3995D', x: 10, y: -170, z: 10 },
  { id: 'graphql_gunslinger', name: 'GraphQL Gunslinger', team: 'Integration & API', color: '#B3995D', x: 15, y: -195, z: 15 },
  { id: 'sync_scout', name: 'Sync Scout', team: 'Integration & API', color: '#B3995D', x: -15, y: -185, z: -15 },
  { id: 'bridge_builder', name: 'Bridge Builder', team: 'Integration & API', color: '#B3995D', x: 5, y: -175, z: 5 },
  { id: 'connector_cowpoke', name: 'Connector Cowpoke', team: 'Integration & API', color: '#B3995D', x: 25, y: -205, z: 25 },
  { id: 'gateway_guardian', name: 'Gateway Guardian', team: 'Integration & API', color: '#B3995D', x: -10, y: -165, z: -10 },

  // TEAM 5: COMMUNICATION (Purple/Red cluster)
  { id: 'message_courier', name: 'Message Courier', team: 'Communication', color: '#AA0000', x: -100, y: 0, z: 200 },
  { id: 'email_express', name: 'Email Express', team: 'Communication', color: '#AA0000', x: -80, y: 20, z: 180 },
  { id: 'sms_sender', name: 'SMS Sender', team: 'Communication', color: '#AA0000', x: -90, y: -20, z: 190 },
  { id: 'notification_herald', name: 'Notification Herald', team: 'Communication', color: '#AA0000', x: -70, y: 10, z: 170 },
  { id: 'broadcast_bandit', name: 'Broadcast Bandit', team: 'Communication', color: '#AA0000', x: -110, y: 15, z: 195 },
  { id: 'alert_ranger', name: 'Alert Ranger', team: 'Communication', color: '#AA0000', x: -95, y: -15, z: 185 },
  { id: 'channel_chief', name: 'Channel Chief', team: 'Communication', color: '#AA0000', x: -85, y: 5, z: 175 },
  { id: 'voice_vaquero', name: 'Voice Vaquero', team: 'Communication', color: '#AA0000', x: -105, y: 25, z: 205 },
  { id: 'chat_champion', name: 'Chat Champion', team: 'Communication', color: '#AA0000', x: -75, y: -10, z: 165 },

  // TEAM 6: FINANCIAL OPS (Emerald/Gold cluster)
  { id: 'ledger_lawman', name: 'Ledger Lawman', team: 'Financial Ops', color: '#B3995D', x: 100, y: 0, z: 200 },
  { id: 'transaction_tracker', name: 'Transaction Tracker', team: 'Financial Ops', color: '#B3995D', x: 80, y: 20, z: 180 },
  { id: 'payment_processor', name: 'Payment Processor', team: 'Financial Ops', color: '#B3995D', x: 90, y: -20, z: 190 },
  { id: 'invoice_inspector', name: 'Invoice Inspector', team: 'Financial Ops', color: '#B3995D', x: 70, y: 10, z: 170 },
  { id: 'reconciliation_ranger', name: 'Reconciliation Ranger', team: 'Financial Ops', color: '#B3995D', x: 110, y: 15, z: 195 },
  { id: 'ar_accountant', name: 'AR Accountant', team: 'Financial Ops', color: '#B3995D', x: 95, y: -15, z: 185 },
  { id: 'ap_auditor', name: 'AP Auditor', team: 'Financial Ops', color: '#B3995D', x: 85, y: 5, z: 175 },
  { id: 'revenue_rider', name: 'Revenue Rider', team: 'Financial Ops', color: '#B3995D', x: 105, y: 25, z: 205 },
  { id: 'expense_enforcer', name: 'Expense Enforcer', team: 'Financial Ops', color: '#B3995D', x: 75, y: -10, z: 165 },

  // TEAM 7: CUSTOMER INTELLIGENCE (Cyan/Gold cluster)
  { id: 'crm_captain', name: 'CRM Captain', team: 'Customer Intelligence', color: '#B3995D', x: -100, y: 0, z: -200 },
  { id: 'contact_curator', name: 'Contact Curator', team: 'Customer Intelligence', color: '#B3995D', x: -80, y: 20, z: -180 },
  { id: 'engagement_explorer', name: 'Engagement Explorer', team: 'Customer Intelligence', color: '#B3995D', x: -90, y: -20, z: -190 },
  { id: 'journey_scout', name: 'Journey Scout', team: 'Customer Intelligence', color: '#B3995D', x: -70, y: 10, z: -170 },
  { id: 'sentiment_sheriff', name: 'Sentiment Sheriff', team: 'Customer Intelligence', color: '#B3995D', x: -110, y: 15, z: -195 },
  { id: 'loyalty_lawman', name: 'Loyalty Lawman', team: 'Customer Intelligence', color: '#B3995D', x: -95, y: -15, z: -185 },
  { id: 'churn_champion', name: 'Churn Champion', team: 'Customer Intelligence', color: '#B3995D', x: -85, y: 5, z: -175 },
  { id: 'feedback_frontiersman', name: 'Feedback Frontiersman', team: 'Customer Intelligence', color: '#B3995D', x: -105, y: 25, z: -205 },
  { id: 'support_specialist', name: 'Support Specialist', team: 'Customer Intelligence', color: '#B3995D', x: -75, y: -10, z: -165 },

  // TEAM 8: AGRICULTURAL INTELLIGENCE (Lime/Green cluster)
  { id: 'grower_guardian', name: 'Grower Guardian', team: 'Agricultural Intelligence', color: '#22c55e', x: 100, y: 0, z: -200 },
  { id: 'harvest_hero', name: 'Harvest Hero', team: 'Agricultural Intelligence', color: '#22c55e', x: 80, y: 20, z: -180 },
  { id: 'crop_commander', name: 'Crop Commander', team: 'Agricultural Intelligence', color: '#22c55e', x: 90, y: -20, z: -190 },
  { id: 'soil_scout', name: 'Soil Scout', team: 'Agricultural Intelligence', color: '#22c55e', x: 70, y: 10, z: -170 },
  { id: 'water_wrangler', name: 'Water Wrangler', team: 'Agricultural Intelligence', color: '#22c55e', x: 110, y: 15, z: -195 },
  { id: 'yield_yodeler', name: 'Yield Yodeler', team: 'Agricultural Intelligence', color: '#22c55e', x: 95, y: -15, z: -185 },
  { id: 'quality_quartermaster', name: 'Quality Quartermaster', team: 'Agricultural Intelligence', color: '#22c55e', x: 85, y: 5, z: -175 },
  { id: 'traceability_tracker', name: 'Traceability Tracker', team: 'Agricultural Intelligence', color: '#22c55e', x: 105, y: 25, z: -205 },
  { id: 'compliance_cowhand', name: 'Compliance Cowhand', team: 'Agricultural Intelligence', color: '#22c55e', x: 75, y: -10, z: -165 },

  // TEAM 9: OPERATIONS COMMAND (Gold cluster - center)
  { id: 'ops_commander', name: 'Ops Commander', team: 'Operations Command', color: '#B3995D', x: 0, y: 0, z: 0 },
  { id: 'resource_ranger', name: 'Resource Ranger', team: 'Operations Command', color: '#B3995D', x: 30, y: 30, z: 30 },
  { id: 'capacity_captain', name: 'Capacity Captain', team: 'Operations Command', color: '#B3995D', x: -30, y: -30, z: -30 },
  { id: 'performance_pioneer', name: 'Performance Pioneer', team: 'Operations Command', color: '#B3995D', x: 30, y: -30, z: 30 },
  { id: 'monitoring_marshal', name: 'Monitoring Marshal', team: 'Operations Command', color: '#B3995D', x: -30, y: 30, z: -30 },
  { id: 'health_handler', name: 'Health Handler', team: 'Operations Command', color: '#B3995D', x: 30, y: 30, z: -30 },
  { id: 'incident_investigator', name: 'Incident Investigator', team: 'Operations Command', color: '#B3995D', x: -30, y: -30, z: 30 },
  { id: 'recovery_rider', name: 'Recovery Rider', team: 'Operations Command', color: '#B3995D', x: 40, y: 0, z: 0 },
  { id: 'uptime_enforcer', name: 'Uptime Enforcer', team: 'Operations Command', color: '#B3995D', x: -40, y: 0, z: 0 }
];

export default function BrainSphere() {
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [brainMetrics, setBrainMetrics] = useState(null);
  const [selectedMiner, setSelectedMiner] = useState(null);
  const [isRotating, setIsRotating] = useState(true);

  // Auto-rotate sphere
  useEffect(() => {
    if (!isRotating) return;
    
    const interval = setInterval(() => {
      setRotation(prev => ({
        x: (prev.x + 0.5) % 360,
        y: (prev.y + 0.3) % 360
      }));
    }, 50);
    
    return () => clearInterval(interval);
  }, [isRotating]);

  // Fetch Brain metrics
  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/brain/status');
        if (res.ok) {
          const data = await res.json();
          setBrainMetrics(data);
        }
      } catch (err) {
        console.log('Brain not available yet');
      }
    };
    
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 2000);
    return () => clearInterval(interval);
  }, []);

  // Calculate 3D projection
  const project3D = (x, y, z, rotX, rotY) => {
    // Simple 3D to 2D projection
    const angleX = (rotX * Math.PI) / 180;
    const angleY = (rotY * Math.PI) / 180;
    
    // Rotate around Y axis
    let x1 = x * Math.cos(angleY) - z * Math.sin(angleY);
    let z1 = x * Math.sin(angleY) + z * Math.cos(angleY);
    
    // Rotate around X axis
    let y1 = y * Math.cos(angleX) - z1 * Math.sin(angleX);
    let z2 = y * Math.sin(angleX) + z1 * Math.cos(angleX);
    
    // Perspective projection
    const perspective = 800;
    const scale = perspective / (perspective + z2);
    
    return {
      x: x1 * scale,
      y: y1 * scale,
      scale,
      z: z2
    };
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #000000 0%, #1a1a1a 100%)',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px'
    }}>
      {/* HEADER */}
      <div style={{
        background: '#000000',
        border: '3px solid #B3995D',
        borderRadius: 0,
        padding: '20px',
        marginBottom: '20px'
      }}>
        <h1 style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', margin: '0 0 8px 0', letterSpacing: '2px' }}>
          THE SPHERE - BRAIN VISUALIZATION
        </h1>
        <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>
          81 Niner Miners • 9 Teams • Real-time Activity Monitoring
        </p>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 350px', gap: '20px', flex: 1 }}>
        {/* SPHERE CONTAINER */}
        <div style={{
          background: '#000000',
          border: '3px solid #B3995D',
          borderRadius: 0,
          position: 'relative',
          overflow: 'hidden',
          minHeight: '700px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
        onMouseEnter={() => setIsRotating(false)}
        onMouseLeave={() => setIsRotating(true)}>
          {/* SPHERE */}
          <svg width="100%" height="700" style={{ position: 'absolute', top: 0, left: 0 }}>
            <defs>
              <radialGradient id="brainGlow">
                <stop offset="0%" stopColor="#B3995D" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#B3995D" stopOpacity="0" />
              </radialGradient>
            </defs>
            
            {/* CENTER BRAIN GLOW */}
            <circle cx="50%" cy="50%" r="100" fill="url(#brainGlow)" />
            
            {/* ALL 81 MINERS AS NODES */}
            {ALL_MINERS.map(miner => {
              const projected = project3D(miner.x, miner.y, miner.z, rotation.x, rotation.y);
              const isActive = brainMetrics?.miners?.[miner.team.replace(/ /g, '')]?.find(m => m.id === miner.id)?.status === 'BUSY';
              
              return (
                <g key={miner.id}>
                  {/* CONNECTION LINE TO CENTER (if active) */}
                  {isActive && (
                    <line
                      x1="50%"
                      y1="50%"
                      x2={`calc(50% + ${projected.x}px)`}
                      y2={`calc(50% + ${projected.y}px)`}
                      stroke={miner.color}
                      strokeWidth="1"
                      opacity="0.3"
                    />
                  )}
                  
                  {/* MINER NODE */}
                  <circle
                    cx={`calc(50% + ${projected.x}px)`}
                    cy={`calc(50% + ${projected.y}px)`}
                    r={isActive ? 8 : 5}
                    fill={miner.color}
                    opacity={projected.z > 0 ? 1 : 0.3}
                    style={{ cursor: 'pointer' }}
                    onClick={() => setSelectedMiner(miner)}
                  />
                </g>
              );
            })}
            
            {/* CENTER BRAIN CORE */}
            <circle cx="50%" cy="50%" r="30" fill="#B3995D" opacity="0.8" />
            <text x="50%" y="50%" textAnchor="middle" dy="5" fill="#000" fontSize="16" fontWeight="700">
              BRAIN
            </text>
          </svg>

          {/* ROTATION CONTROLS */}
          <div style={{
            position: 'absolute',
            bottom: '20px',
            left: '20px',
            display: 'flex',
            gap: '10px'
          }}>
            <button
              onClick={() => setIsRotating(!isRotating)}
              style={{
                padding: '10px 20px',
                background: isRotating ? '#AA0000' : '#B3995D',
                border: 'none',
                borderRadius: 0,
                color: '#000',
                fontSize: '12px',
                fontWeight: '700',
                cursor: 'pointer'
              }}
            >
              {isRotating ? 'PAUSE' : 'ROTATE'}
            </button>
          </div>
        </div>

        {/* SIDEBAR INFO */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* BRAIN METRICS */}
          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <h2 style={{ color: '#B3995D', fontSize: '16px', fontWeight: '700', marginBottom: '16px' }}>
              BRAIN METRICS
            </h2>
            {brainMetrics ? (
              <>
                <div style={{ marginBottom: '12px' }}>
                  <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '4px' }}>ACTIVE MINERS</div>
                  <div style={{ color: '#22c55e', fontSize: '24px', fontWeight: '700', fontFamily: 'monospace' }}>
                    {brainMetrics.metrics.activeMiners}/81
                  </div>
                </div>
                <div style={{ marginBottom: '12px' }}>
                  <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '4px' }}>BUSY MINERS</div>
                  <div style={{ color: '#B3995D', fontSize: '24px', fontWeight: '700', fontFamily: 'monospace' }}>
                    {brainMetrics.metrics.busyMiners}
                  </div>
                </div>
                <div style={{ marginBottom: '12px' }}>
                  <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '4px' }}>ACTIVE WORKFLOWS</div>
                  <div style={{ color: '#AA0000', fontSize: '24px', fontWeight: '700', fontFamily: 'monospace' }}>
                    {brainMetrics.activeWorkflows}
                  </div>
                </div>
                <div>
                  <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '4px' }}>COMPLETED TASKS</div>
                  <div style={{ color: '#B3995D', fontSize: '24px', fontWeight: '700', fontFamily: 'monospace' }}>
                    {brainMetrics.metrics.completedTasks.toLocaleString()}
                  </div>
                </div>
              </>
            ) : (
              <div style={{ color: '#64748b', fontSize: '12px' }}>Loading Brain data...</div>
            )}
          </div>

          {/* SELECTED MINER */}
          {selectedMiner && (
            <div style={{
              background: '#000000',
              border: `2px solid ${selectedMiner.color}`,
              borderRadius: 0,
              padding: '20px'
            }}>
              <h2 style={{ color: selectedMiner.color, fontSize: '14px', fontWeight: '700', marginBottom: '8px' }}>
                {selectedMiner.name}
              </h2>
              <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '12px' }}>
                {selectedMiner.team}
              </div>
              <div style={{ color: '#64748b', fontSize: '10px' }}>
                Status: <span style={{ color: '#22c55e' }}>ACTIVE</span>
              </div>
              <button
                onClick={() => setSelectedMiner(null)}
                style={{
                  marginTop: '12px',
                  padding: '8px 16px',
                  background: '#1a1a1a',
                  border: `1px solid ${selectedMiner.color}`,
                  borderRadius: 0,
                  color: selectedMiner.color,
                  fontSize: '10px',
                  fontWeight: '700',
                  cursor: 'pointer'
                }}
              >
                CLOSE
              </button>
            </div>
          )}

          {/* LEGEND */}
          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <h2 style={{ color: '#B3995D', fontSize: '14px', fontWeight: '700', marginBottom: '12px' }}>
              TEAM COLORS
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '12px', height: '12px', background: '#22c55e' }} />
                <span style={{ color: '#94a3b8' }}>Data Intelligence (9)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '12px', height: '12px', background: '#B3995D' }} />
                <span style={{ color: '#94a3b8' }}>Workflow/API/Financial/CRM/Ops (45)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '12px', height: '12px', background: '#AA0000' }} />
                <span style={{ color: '#94a3b8' }}>Security/Communication (18)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '12px', height: '12px', background: '#22c55e' }} />
                <span style={{ color: '#94a3b8' }}>Agricultural Intelligence (9)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
