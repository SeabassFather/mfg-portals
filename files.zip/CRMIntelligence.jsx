// =============================================================================
// CRM INTELLIGENCE MODULE
// =============================================================================
// 9 Customer Intelligence Niner Miners
// 49ers Colors: Black #000000, Gold #B3995D, Red #AA0000
// Manages: Customer insights, engagement, sentiment, journeys, loyalty
// =============================================================================

import React, { useState, useEffect } from 'react';

const CRM_MINERS = [
  { id: 'crm_captain', name: 'CRM Captain', status: 'ACTIVE', currentTask: 'Customer data synchronization', tasksCompleted: 3456 },
  { id: 'contact_curator', name: 'Contact Curator', status: 'ACTIVE', currentTask: 'Contact enrichment', tasksCompleted: 2789 },
  { id: 'engagement_explorer', name: 'Engagement Explorer', status: 'ACTIVE', currentTask: 'Tracking email engagement', tasksCompleted: 4123 },
  { id: 'journey_scout', name: 'Journey Scout', status: 'ACTIVE', currentTask: 'Mapping customer journeys', tasksCompleted: 1567 },
  { id: 'sentiment_sheriff', name: 'Sentiment Sheriff', status: 'ACTIVE', currentTask: 'Analyzing customer sentiment', tasksCompleted: 2890 },
  { id: 'loyalty_lawman', name: 'Loyalty Lawman', status: 'ACTIVE', currentTask: 'Loyalty program tracking', tasksCompleted: 1234 },
  { id: 'churn_champion', name: 'Churn Champion', status: 'ACTIVE', currentTask: 'Churn prediction analysis', tasksCompleted: 987 },
  { id: 'feedback_frontiersman', name: 'Feedback Frontiersman', status: 'ACTIVE', currentTask: 'Processing customer feedback', tasksCompleted: 2145 },
  { id: 'support_specialist', name: 'Support Specialist', status: 'ACTIVE', currentTask: 'Support ticket analysis', tasksCompleted: 3678 }
];

export default function CRMIntelligence() {
  const [miners, setMiners] = useState(CRM_MINERS);
  const [metrics, setMetrics] = useState({
    activeCustomers: Math.floor(Math.random() * 500) + 1200,
    engagementRate: Math.floor(Math.random() * 10) + 65,
    avgSentiment: (Math.random() * 0.5 + 4.0).toFixed(1),
    churnRisk: Math.floor(Math.random() * 5) + 8
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics({
        activeCustomers: Math.floor(Math.random() * 500) + 1200,
        engagementRate: Math.floor(Math.random() * 10) + 65,
        avgSentiment: (Math.random() * 0.5 + 4.0).toFixed(1),
        churnRisk: Math.floor(Math.random() * 5) + 8
      });
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, rgba(0,0,0,0.98) 0%, rgba(26,26,26,0.95) 100%)',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* BACKGROUND PATTERN */}
      <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, opacity: 0.03 }}>
        <defs>
          <pattern id="crm-grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(179,153,93,0.05)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#crm-grid)" />
      </svg>

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* HEADER */}
        <div style={{
          background: '#000000',
          border: '3px solid #B3995D',
          borderTop: '6px solid #AA0000',
          borderRadius: 0,
          padding: '24px',
          marginBottom: '24px'
        }}>
          <h1 style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', margin: '0 0 8px 0', letterSpacing: '2px' }}>
            CRM INTELLIGENCE CENTER
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>
            9 Customer Intelligence Niner Miners • 360° Customer Insights
          </p>
        </div>

        {/* METRICS ROW */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              ACTIVE CUSTOMERS
            </div>
            <div style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.activeCustomers}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              ENGAGEMENT RATE
            </div>
            <div style={{ color: '#22c55e', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.engagementRate}%
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              AVG SENTIMENT
            </div>
            <div style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.avgSentiment}/5
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #AA0000',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              CHURN RISK
            </div>
            <div style={{ color: '#AA0000', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.churnRisk}%
            </div>
          </div>
        </div>

        {/* MAIN GRID */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* NINER MINERS PANEL */}
          <div style={{
            background: '#000000',
            border: '3px solid #B3995D',
            borderRadius: 0,
            padding: '24px'
          }}>
            <h2 style={{ color: '#B3995D', fontSize: '20px', fontWeight: '700', marginBottom: '20px', letterSpacing: '1px' }}>
              CRM NINER MINERS
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {miners.map(miner => (
                <div
                  key={miner.id}
                  style={{
                    background: '#000000',
                    border: '2px solid #B3995D',
                    borderRadius: 0,
                    padding: '16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '4px' }}>
                      <div style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: miner.status === 'ACTIVE' ? '#22c55e' : '#B3995D'
                      }} />
                      <span style={{ color: '#B3995D', fontSize: '14px', fontWeight: '700' }}>
                        {miner.name}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '11px', marginLeft: '20px' }}>
                      {miner.currentTask}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', fontFamily: 'monospace' }}>
                      {miner.tasksCompleted.toLocaleString()}
                    </div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>TASKS</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ACTIVITY PANEL */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* CUSTOMER INSIGHTS */}
            <div style={{
              background: '#000000',
              border: '3px solid #B3995D',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                RECENT CUSTOMER ACTIVITY
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[
                  { customer: 'Acme Growers LLC', activity: 'Purchased 500kg avocados', sentiment: 'POSITIVE', time: '2m ago' },
                  { customer: 'Fresh Produce Co', activity: 'Opened email campaign', sentiment: 'NEUTRAL', time: '5m ago' },
                  { customer: 'Green Valley Farms', activity: 'Support ticket created', sentiment: 'NEGATIVE', time: '8m ago' },
                  { customer: 'SunRipe Distributors', activity: 'Completed transaction', sentiment: 'POSITIVE', time: '12m ago' },
                  { customer: 'Harvest Moon Inc', activity: 'Downloaded report', sentiment: 'NEUTRAL', time: '15m ago' }
                ].map((item, i) => (
                  <div key={i} style={{
                    background: '#000000',
                    border: '1px solid #B3995D',
                    borderRadius: 0,
                    padding: '12px'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ color: '#B3995D', fontSize: '12px', fontWeight: '600' }}>{item.customer}</span>
                      <span style={{
                        color: item.sentiment === 'POSITIVE' ? '#22c55e' : item.sentiment === 'NEUTRAL' ? '#B3995D' : '#AA0000',
                        fontSize: '10px',
                        fontWeight: '700'
                      }}>
                        {item.sentiment}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '2px' }}>{item.activity}</div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>{item.time}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* ENGAGEMENT METRICS */}
            <div style={{
              background: '#000000',
              border: '3px solid #B3995D',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                ENGAGEMENT METRICS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Email Open Rate</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700' }}>
                      68%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '68%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Support Satisfaction</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700' }}>
                      92%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '92%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Repeat Purchase Rate</span>
                    <span style={{ color: '#B3995D', fontSize: '14px', fontWeight: '700' }}>
                      78%
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #AA0000 100%)',
                      height: '100%',
                      width: '78%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
