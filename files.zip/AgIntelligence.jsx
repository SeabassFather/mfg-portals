// =============================================================================
// AGRICULTURAL INTELLIGENCE MODULE
// =============================================================================
// 9 Agricultural Intelligence Niner Miners
// 49ers Colors: Black #000000, Gold #B3995D, Red #AA0000, Green #22c55e
// Manages: Growers, Crops, Soil, Water, Quality, Traceability, Compliance
// =============================================================================

import React, { useState, useEffect } from 'react';

const AG_MINERS = [
  { id: 'grower_guardian', name: 'Grower Guardian', status: 'ACTIVE', currentTask: 'Monitoring 5,247 grower profiles', tasksCompleted: 4123 },
  { id: 'harvest_hero', name: 'Harvest Hero', status: 'ACTIVE', currentTask: 'Tracking harvest schedules', tasksCompleted: 2891 },
  { id: 'crop_commander', name: 'Crop Commander', status: 'ACTIVE', currentTask: 'Crop quality assessment', tasksCompleted: 3567 },
  { id: 'soil_scout', name: 'Soil Scout', status: 'ACTIVE', currentTask: 'Soil analysis processing', tasksCompleted: 1789 },
  { id: 'water_wrangler', name: 'Water Wrangler', status: 'ACTIVE', currentTask: 'Water quality testing (155 params)', tasksCompleted: 2456 },
  { id: 'yield_yodeler', name: 'Yield Yodeler', status: 'ACTIVE', currentTask: 'Yield predictions for avocados', tasksCompleted: 1234 },
  { id: 'quality_quartermaster', name: 'Quality Quartermaster', status: 'ACTIVE', currentTask: 'USDA quality grading', tasksCompleted: 3098 },
  { id: 'traceability_tracker', name: 'Traceability Tracker', status: 'ACTIVE', currentTask: 'FSMA 204 traceability logs', tasksCompleted: 2678 },
  { id: 'compliance_cowhand', name: 'Compliance Cowhand', status: 'ACTIVE', currentTask: 'GAP compliance verification', tasksCompleted: 1890 }
];

export default function AgIntelligence() {
  const [miners, setMiners] = useState(AG_MINERS);
  const [metrics, setMetrics] = useState({
    activeGrowers: Math.floor(Math.random() * 500) + 5000,
    cropAnalyses: Math.floor(Math.random() * 100) + 250,
    waterTests: Math.floor(Math.random() * 50) + 120,
    complianceRate: Math.floor(Math.random() * 3) + 97
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics({
        activeGrowers: Math.floor(Math.random() * 500) + 5000,
        cropAnalyses: Math.floor(Math.random() * 100) + 250,
        waterTests: Math.floor(Math.random() * 50) + 120,
        complianceRate: Math.floor(Math.random() * 3) + 97
      });
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, rgba(0,0,0,0.98) 0%, rgba(26,26,26,0.95) 100%)',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* BACKGROUND PATTERN */}
      <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, opacity: 0.03 }}>
        <defs>
          <pattern id="ag-grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(34,197,94,0.05)" strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#ag-grid)" />
      </svg>

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* HEADER */}
        <div style={{
          background: '#000000',
          border: '3px solid #22c55e',
          borderTop: '6px solid #AA0000',
          borderRadius: 0,
          padding: '24px',
          marginBottom: '24px'
        }}>
          <h1 style={{ color: '#22c55e', fontSize: '32px', fontWeight: '700', margin: '0 0 8px 0', letterSpacing: '2px' }}>
            AGRICULTURAL INTELLIGENCE CENTER
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>
            9 Agricultural Intelligence Niner Miners • Farm-to-Market Intelligence
          </p>
        </div>

        {/* METRICS ROW */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
          <div style={{
            background: '#000000',
            border: '2px solid #22c55e',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              ACTIVE GROWERS
            </div>
            <div style={{ color: '#22c55e', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.activeGrowers}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              CROP ANALYSES (24H)
            </div>
            <div style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.cropAnalyses}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #B3995D',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              WATER TESTS (24H)
            </div>
            <div style={{ color: '#B3995D', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.waterTests}
            </div>
          </div>

          <div style={{
            background: '#000000',
            border: '2px solid #22c55e',
            borderRadius: 0,
            padding: '20px'
          }}>
            <div style={{ color: '#64748b', fontSize: '11px', fontWeight: '600', marginBottom: '8px', letterSpacing: '1px' }}>
              COMPLIANCE RATE
            </div>
            <div style={{ color: '#22c55e', fontSize: '32px', fontWeight: '700', fontFamily: 'monospace' }}>
              {metrics.complianceRate}%
            </div>
          </div>
        </div>

        {/* MAIN GRID */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* NINER MINERS PANEL */}
          <div style={{
            background: '#000000',
            border: '3px solid #22c55e',
            borderRadius: 0,
            padding: '24px'
          }}>
            <h2 style={{ color: '#22c55e', fontSize: '20px', fontWeight: '700', marginBottom: '20px', letterSpacing: '1px' }}>
              AG INTELLIGENCE NINER MINERS
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {miners.map(miner => (
                <div
                  key={miner.id}
                  style={{
                    background: '#000000',
                    border: '2px solid #22c55e',
                    borderRadius: 0,
                    padding: '16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '4px' }}>
                      <div style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: miner.status === 'ACTIVE' ? '#22c55e' : '#B3995D'
                      }} />
                      <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700' }}>
                        {miner.name}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '11px', marginLeft: '20px' }}>
                      {miner.currentTask}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', fontFamily: 'monospace' }}>
                      {miner.tasksCompleted.toLocaleString()}
                    </div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>TASKS</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ACTIVITY PANEL */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {/* RECENT ACTIVITIES */}
            <div style={{
              background: '#000000',
              border: '3px solid #22c55e',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#22c55e', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                RECENT AG ACTIVITIES
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[
                  { grower: 'Valle Verde Farms', activity: 'Avocado harvest completed', quality: 'EXCELLENT', time: '1m ago' },
                  { grower: 'Rancho San Miguel', activity: 'Water test: 155 params passed', quality: 'GOOD', time: '4m ago' },
                  { grower: 'Finca El Roble', activity: 'Soil analysis submitted', quality: 'GOOD', time: '7m ago' },
                  { grower: 'AgriSol Exports', activity: 'GAP compliance verified', quality: 'EXCELLENT', time: '11m ago' },
                  { grower: 'Green Horizon Co-op', activity: 'Strawberry yield forecast', quality: 'FAIR', time: '14m ago' }
                ].map((item, i) => (
                  <div key={i} style={{
                    background: '#000000',
                    border: '1px solid #22c55e',
                    borderRadius: 0,
                    padding: '12px'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ color: '#22c55e', fontSize: '12px', fontWeight: '600' }}>{item.grower}</span>
                      <span style={{
                        color: item.quality === 'EXCELLENT' ? '#22c55e' : item.quality === 'GOOD' ? '#B3995D' : '#f97316',
                        fontSize: '10px',
                        fontWeight: '700'
                      }}>
                        {item.quality}
                      </span>
                    </div>
                    <div style={{ color: '#64748b', fontSize: '10px', marginBottom: '2px' }}>{item.activity}</div>
                    <div style={{ color: '#64748b', fontSize: '9px' }}>{item.time}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* CROP METRICS */}
            <div style={{
              background: '#000000',
              border: '3px solid #B3995D',
              borderRadius: 0,
              padding: '24px'
            }}>
              <h2 style={{ color: '#B3995D', fontSize: '18px', fontWeight: '700', marginBottom: '16px' }}>
                CROP PRODUCTION METRICS
              </h2>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Avocados (lbs/week)</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700', fontFamily: 'monospace' }}>
                      1.2M
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '92%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Strawberries (lbs/week)</span>
                    <span style={{ color: '#22c55e', fontSize: '14px', fontWeight: '700', fontFamily: 'monospace' }}>
                      850K
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #22c55e 100%)',
                      height: '100%',
                      width: '78%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ color: '#64748b', fontSize: '11px' }}>Leafy Greens (lbs/week)</span>
                    <span style={{ color: '#B3995D', fontSize: '14px', fontWeight: '700', fontFamily: 'monospace' }}>
                      450K
                    </span>
                  </div>
                  <div style={{ background: '#1a1a1a', height: '6px', borderRadius: 0 }}>
                    <div style={{
                      background: 'linear-gradient(90deg, #B3995D 0%, #AA0000 100%)',
                      height: '100%',
                      width: '65%',
                      borderRadius: 0
                    }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
